create function f(_s text)
  returns numeric
language plpgsql
as $$
declare i numeric;
begin
    execute format('select %s', _s) into i;
    return i;
end;
$$;

alter function f(text)
  owner to postgres;

